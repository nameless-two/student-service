package telran.java52.student.dto;

import lombok.Getter;

@Getter
public class StudentUpdateDto {

	String name;
	String password;

}
